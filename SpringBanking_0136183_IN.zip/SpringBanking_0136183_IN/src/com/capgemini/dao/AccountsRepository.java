package com.capgemini.dao;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;

import com.capgemini.dto.AccountsDTO;
import com.capgemini.dto.TransactionDTO;




@Component("dao")
public class AccountsRepository {
	
	EntityManagerFactory factory = Persistence
			.createEntityManagerFactory("JPA-PU");
	EntityManager entityManager = factory.createEntityManager();
	
	
	public List<AccountsDTO>getAccountDetails(AccountsDTO accountsDTO)
	{
		//entityManager.getTransaction().begin();
		List<AccountsDTO>accountdetailsList=new ArrayList<AccountsDTO>();
			 
		TypedQuery<AccountsDTO> query = entityManager.createQuery("SELECT accountsDTOExt"
			 		+ " FROM "+AccountsDTO.class.getName()+" accountsDTOExt "
			 		+ "where accountsDTOExt.custName=:ptitle", AccountsDTO.class);
		query.setParameter("ptitle", accountsDTO.getCustName());
				
		accountdetailsList=query.getResultList();
		//entityManager.getTransaction().commit();
		//entityManager.close();
		//factory.close();
		return accountdetailsList;
	}
	
	public  void insertTransactionDetails(TransactionDTO transactionDTO)
	{
		entityManager.getTransaction().begin();
		entityManager.persist(transactionDTO);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		factory.close();
	}

}
