package com.capgemini.dto;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class AccountsDTO implements Serializable 
{
	private String accountNum;
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="^[A-Z][A-Za-z\t]{,14}$",message="Enter Valid Pattern")
	private String custName;
	private String accountType;
	private String accountLoc;
	private double balance;
	public String getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountLoc() {
		return accountLoc;
	}
	public void setAccountLoc(String accountLoc) {
		this.accountLoc = accountLoc;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public AccountsDTO() {
		super();
	}
	

}
