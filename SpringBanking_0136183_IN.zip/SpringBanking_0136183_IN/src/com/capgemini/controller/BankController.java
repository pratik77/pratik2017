package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.dao.AccountsDAO;
import com.capgemini.dto.AccountsDTO;


@Scope("session")
@Controller
@RequestMapping(value="bank")
public class BankController {
	
	@Autowired
	AccountsDAO accountsDAO;
	
	
	
	@RequestMapping(value="/customerMenu")
	public String customerMenu(Model model)
	{
		System.out.println("In checkCustomer() method");
		model.addAttribute("accountsDTO",new AccountsDTO());
		return "Home";
	}
	
	@RequestMapping(value="/checkCustomer")
	public String checkCustomer(@ModelAttribute("accountsDTO")
	@Valid AccountsDTO accountsDTO,
			BindingResult result,Model model)
	{
		if(result.hasErrors())
			return "Home";
		
		List<AccountsDTO> accountDetailsList=new ArrayList<AccountsDTO>();
		accountDetailsList= accountsDAO.getAccountDetails(accountsDTO);
		if(accountDetailsList.size()!=0)
		{
			
			model.addAttribute("accountDetailsList",accountDetailsList);
			model.addAttribute("custName",accountsDTO.getCustName());
			return "AccountInfo";
		}
		else
		{
			model.addAttribute("custName",accountsDTO.getCustName());
			return "ErrorAccountInfo";
		}
	}

}
