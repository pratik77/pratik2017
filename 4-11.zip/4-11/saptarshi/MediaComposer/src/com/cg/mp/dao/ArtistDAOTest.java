package com.cg.mp.dao;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.exception.SongException;

public class ArtistDAOTest {
	
	@Test
	public void testGetArtistId() throws SongException {
		IArtistDAO dao=new ArtistDAO();
		ArtistMasterDTO artist=new ArtistMasterDTO();
		int status=dao.addNewArtist(artist);
		assertEquals(1, status);
	}

	@Test
	public void testDeleteArtistDetails() throws SongException {
		IArtistDAO dao=new ArtistDAO();
		ArtistMasterDTO artist=new ArtistMasterDTO();
		int deletestatus=dao.deleteArtistDetails(42);
		assertEquals(1, deletestatus);
	}

}
