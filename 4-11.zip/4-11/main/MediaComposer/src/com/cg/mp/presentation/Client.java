package com.cg.mp.presentation;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.dto.ComposerMasterDTO;
import com.cg.mp.dto.SongMasterDTO;
import com.cg.mp.dto.UserMasterDTO;
import com.cg.mp.exception.SongException;
import com.cg.mp.service.ISongService;
import com.cg.mp.service.SongService;

public class Client {

	public static void main(String[] args) {
		
		/**************Object Creation*****************/
		ISongService songService=new SongService();
		ComposerMasterDTO composerMasterDTO=new ComposerMasterDTO();
		UserMasterDTO userMasterDTO=new UserMasterDTO();
		ArtistMasterDTO artistMasterDTO=new ArtistMasterDTO();
		ClientArtist clientTest=new ClientArtist();
		Scanner sc = new Scanner(System.in);
		/************************************************/
		
		/************************Variable declaration and initialization*********************/
		int choice1,choice2,choice3,userId,composerId=0,count=0,artistId=0;
		String composerName="",choice7="";
		String composerBorn="",composerDied="",composerCaeipiNumber="",composerMusicSocId="";
		List<SongMasterDTO>songsList=new ArrayList();
		char choice5;
		String password;
		String checkLogin="invalid";
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		/************************************************************************************/
		
		/**********************Regex pattern initialization*******************/
		String patternId="[0-9]{6}";
		String patternName="^[A-Za-z]{1,50}$";
		String patternDate="[1-2][0-9][0-9]{2}[-][0-1][0-9][-][0-3][0-9]";
		String patternCaeipi="[0-9]{7,10}";
		String patternMusSocId="[A-Za-z0-9]{3}";
		/**********************************************************************/
			
		/*************do while loop for main menu***************/
		do
		{
			System.out.println("Enter choice");
			System.out.println("*************");
			System.out.println("1.Login");
			System.out.println("2.Sign Up");
			System.out.println("3.Exit :(");
			choice1=sc.nextInt();
			
			/*switch case main menu*/
			switch(choice1)
			{
			case 1:
				count=3;
				
				/*do while loop for taking credentials max upto 3 times*/
				do
				{
					System.out.println("Enter Credentials");
					System.out.print("UserId (no space in userId): ");
					userId=sc.nextInt();
					System.out.println("Password: ");
					password=sc.next();
					checkLogin="invalid";
					try {
						checkLogin=songService.checkLogin(userId,password);
					} catch (SongException e) {
						e.getMessage();
					}
					if(checkLogin=="admin")
					{
						System.out.println("Hello Admin.");
						System.out.println("****************");
						
						/*do while loop for admin menu*/
						do
						{
							System.out.println("Admin Menu:");
							System.out.println();
							System.out.println("1.  Add a Composer.");
							System.out.println("2.  Search for a Composer");
							System.out.println("3.  Edit an existing Composer details.");
							System.out.println("4.  Delete a Composer.");
							System.out.println("5.  Show all Composer.");
							System.out.println("6.  Associate song/songs to a Composer.");
							System.out.println("7.  Add an Artist."); 
							System.out.println("8.  Search for an Artist");
							System.out.println("9.  Edit an existing Artist details.");
							System.out.println("10. Delete an Artist.");
							System.out.println("11. Show all Artists.");
							System.out.println("12. Associate song/songs to an Artist.");
							System.out.println("13. Add Songs.");
							System.out.println("14. Logout");
							System.out.println("Enter choice:");
							choice3=sc.nextInt();
							
							/*switch case for admin menu*/
							switch(choice3)
							{
							case 1:
								do
								{
									System.out.println("Enter Composer name:");
									composerName=sc.next()+sc.nextLine();
									choice7="";
								//	if(Pattern.matches(patternName,composerName)==false)
									if(composerName.matches("^[A-Za-z][A-Za-z ]{1,50}$")==false)
									{
										try
										{
											throw new SongException("Please enter a valid name. Only alphabets and blanks spaces allowed");
										}catch(SongException e)
										{
											System.out.println(e.getMessage());
											choice7="again";
										}
								}
								}while(choice7=="again");
								
								do
								{
									System.out.println("Enter Composer Born date:");
									composerBorn=sc.next();
									choice7="";
									if(composerBorn.matches("[1-2][0-9][0-9]{2}[-][0-1][0-9][-][0-3][0-9]")==false)
									{
										try
										{
											throw new SongException("Please enter a valid date in yyyy-mm-dd format");
										}catch(SongException e)
										{
											System.out.println(e.getMessage());
											choice7="again";
										}
								    }
								
								}while(choice7=="again");
								formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
								LocalDate bornDateLocal=LocalDate.parse(composerBorn,formatter);
								Date composerBornDate=Date.valueOf(bornDateLocal);
								
								System.out.println("Is the composer dead?(y/n)");
								String choice4=sc.next();
								if(choice4.equals("Y") || choice4.equals("y"))
								{
									do
									{
										System.out.println("Enter Composer Died date:");
										composerDied=sc.next();
										choice7="";
										if(composerDied.matches("[1-2][0-9][0-9]{2}[-][0-1][0-9][-][0-3][0-9]")==false)
										{
											try
											{
												throw new SongException("Please enter a valid date in yyyy-mm-dd format");
											}catch(SongException e)
											{
												System.out.println(e.getMessage());
												choice7="again";
											}
									    }
									
									}while(choice7=="again");
									
									LocalDate diedDateLocal=LocalDate.parse(composerDied,formatter);
									Date composerDiedDate=Date.valueOf(diedDateLocal);
									composerMasterDTO.setComposerDiedDate(composerDiedDate);
								}
								else
									composerMasterDTO.setComposerDiedDate(null);
								
								do
								{
								System.out.println("Enter Composer Caeipi number:");
								composerCaeipiNumber=sc.next();
								choice7="";
								if(composerCaeipiNumber.matches("[0-9]{7,10}")==false)
								{
									try
									{
										throw new SongException("Please enter a valid cae/ipi number. Only numbers allowed and length "
												+ "between 7 digits and 10 digits allowed only.");
									}catch(SongException e)
									{
										System.out.println(e.getMessage());
										choice7="again";
									}
							    }
								}while(choice7=="again");
								
								do
								{
								System.out.println("Enter Composer Music Society Id");
								composerMusicSocId=sc.next();
								choice7="";
								if(composerMusicSocId.matches("[A-Za-z0-9]{3}")==false)
								{
									try
									{
										throw new SongException("Please enter a valid 3 letters Id. Note: music society id is case sensitive.");
									}catch(SongException e)
									{
										System.out.println(e.getMessage());
										choice7="again";
									}
							    }
								}while(choice7=="again");
								
								composerMasterDTO.setComposerName(composerName);
								composerMasterDTO.setComposerBornDate(composerBornDate);
								composerMasterDTO.setComposerCaeipiNumber(composerCaeipiNumber);
								composerMasterDTO.setComposerMusicSocId(composerMusicSocId);
								composerMasterDTO.setComposerDelFlag(1);
								try {

									System.out.println("Composer succesfully added with composer Id="
											+songService.addComposer(composerMasterDTO,userId));
								} catch (SongException e) {
									// TODO Auto-generated catch block
									System.out.println(e.getMessage());
								}
								break;
							case 2:
								System.out.println("Enter composer id:");
								composerId=sc.nextInt();
								try {
									composerMasterDTO=songService.getComposerById(composerId);
									if(composerMasterDTO.getComposerName()==null)
									{
										try
										{
											throw new SongException("The composer you are searching for is unavailable.");
										}
										catch(SongException e) {
											System.out.println(e.getMessage());
										}
									}

									else
										System.out.println(composerMasterDTO);
								} catch (SongException e) {
									// TODO Auto-generated catch block
									System.out.println(e.getMessage());
								}

								break;
							case 3:
								System.out.println("Enter the composer Id you want to edit: ");
								composerId=sc.nextInt();
								System.out.println("What do u want to edit?");
								System.out.println("*************************");
								System.out.println("1.Death Date");
								System.out.println("2.Caeipi number");
								System.out.println("3.Music Society Id");
								System.out.println("Enter choice: ");
								int choice6=sc.nextInt();
								ComposerMasterDTO composerMasterDTOEdit=new ComposerMasterDTO();
								switch(choice6)
								{
								case 1:
									System.out.println("Enter the death date in yyyy-mm-dd format: ");
									String deathDate=sc.next();
									formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
									LocalDate deathDateLocal=LocalDate.parse(deathDate,formatter);
									Date deathDateDate=Date.valueOf(deathDateLocal);
									composerMasterDTOEdit.setComposerDiedDate(deathDateDate);
									composerMasterDTOEdit.setComposerId(composerId);
									try {
										songService.editComposerDetails(composerMasterDTOEdit,choice6,userId);
										System.out.println("Composer details succesfully edited");
									} catch (SongException e) {
										// TODO Auto-generated catch block
										System.out.println(e.getMessage());
									}

									break;
								case 2:
									System.out.println("Enter the Caeipi number: ");
									String CaeipiNumber=sc.next();
									composerMasterDTOEdit.setComposerCaeipiNumber(CaeipiNumber);
									composerMasterDTOEdit.setComposerId(composerId);
									try {
										songService.editComposerDetails(composerMasterDTOEdit,choice6,userId);
										System.out.println("Composer details succesfully edited");
									} catch (SongException e) {
										// TODO Auto-generated catch block
										System.out.println(e.getMessage());
									}

									break;
								case 3:
									System.out.println("Enter the Music Society Id: ");
									String musicSocId=sc.next();
									composerMasterDTOEdit.setComposerMusicSocId(musicSocId);
									composerMasterDTOEdit.setComposerId(composerId);
									try {
										songService.editComposerDetails(composerMasterDTOEdit,choice6,userId);
										System.out.println("Composer details succesfully edited");
									} catch (SongException e) {
										// TODO Auto-generated catch block
										System.out.println(e.getMessage());
									}

									break;
								}
								break;
								
								/****************Case 4********************/
							case 4:
								System.out.println("Enter the composer Id you want to delete: ");
								composerId=sc.nextInt();
								try {
									songService.deleteComposerDetails(composerId);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									System.out.println(e.getMessage());
								}
								break;
							case 5:
								List<ComposerMasterDTO>composerList=new ArrayList();
								try {
									composerList=songService.showAllComposerDetails();
									for(ComposerMasterDTO composerMasterDTOList:composerList)
										System.out.println(composerMasterDTOList);
								} catch (SongException e) {
									// TODO Auto-generated catch block
									System.out.println(e.getMessage());
								}
								break;
								
								
								/****************Case 5********************/
							case 7:
								System.out.println("Enter Artist Name:");
								sc.nextLine();
								String artistName=sc.nextLine();
								if(artistName.matches("[A-Za-z][A-Za-z ]{1,}"))
								{
									String newArtistName=artistName.toLowerCase();
									System.out.println("ENter the Artist Type:M for Male and F for Female");
									String artistType=sc.next();
									if(artistType.equals("M")|| artistType.equals("F"))
									{
										System.out.println("Enter Artist Born date:");
										String artistBorn=sc.next();
										LocalDate artistBornDateLocal=LocalDate.parse(artistBorn,formatter);
										Date artistBornDate=Date.valueOf(artistBornDateLocal);
										if(artistBornDate.after(Date.valueOf(LocalDate.now())))
										{
											System.out.println("Birth date must be before the current date.");
											break;
										}
										System.out.println("Is the Artist dead?(y/n)");
										choice4=sc.next();
										if(choice4.equals("Y") || choice4.equals("y"))
										{
											System.out.println("Enter Artist Died date:yyyy-mm-dd format");
											composerDied=sc.next();
											LocalDate diedDateLocal=LocalDate.parse(composerDied,formatter);
											Date artistDiedDate=Date.valueOf(diedDateLocal);
											Date sysDate=Date.valueOf(LocalDate.now());
											if(artistDiedDate.after(artistBornDate) && artistDiedDate.before(sysDate))
											{
												artistMasterDTO.setArtistDiedDate(artistDiedDate);
											}
											else
											{
												System.out.println("Death date should be after birthdate.");
												break;	
											}
												
											
										}
										else
											artistMasterDTO.setArtistDiedDate(null);
											
										
										System.out.println("Deletion Status:");
										int artistDeletion=sc.nextInt();
										artistMasterDTO.setArtistName(newArtistName);
										artistMasterDTO.setArtistBornDate(artistBornDate);
										artistMasterDTO.setArtistType(artistType);
										artistMasterDTO.setCreatedBy(userId);
										artistMasterDTO.setUpdatedBy(userId);
										artistMasterDTO.setArtistDelFlag(artistDeletion);
										int status=0;
										try {
											
											status=songService.addNewArtist(artistMasterDTO);
											System.out.println("Artist succesfully added with Artist Id="+status);
										} catch (SongException e) {
											System.out.println(e.getMessage());
										}
										
									}
									else
										System.out.println("Enter a valid Artist Type");
								}
								else
									System.out.println("Enter a valid Artist Name");
							break;
							
							case 8:
								System.out.println("Enter the artist Id:");
								artistId=sc.nextInt();
								List<ArtistMasterDTO> artistMasterList=new ArrayList();
								try {
									artistMasterList = songService.searchArtist(artistId);
								} catch (SongException e1) {
									// TODO Auto-generated catch block
									System.out.println(e1.getMessage());
								}
								if(artistMasterList.isEmpty())
								{
									try
									{
										throw new SongException("The Artist you are searching for is unavailable.");
									}
									catch(SongException e)
									{
										System.out.println(e.getMessage());
									}
								}
								else
								{
									for(ArtistMasterDTO ArtistMasterDTO:artistMasterList )
									{
										System.out.println(ArtistMasterDTO);
									}
								}
								break;
							case 9:
								try {
									clientTest.clientArtistTest("3");
								} catch (SongException e) {
									// TODO Auto-generated catch block
									System.out.println(e.getMessage());
								}
								break;

							}
							System.out.println("Want to continue (y/n)");
							choice5=sc.next().charAt(0);
						}while(choice5 =='y' || choice5=='Y');
						System.out.println("Thank you for your time. Hope to see you soon again. Cheers :)");
					}
					
					
					
					/***********************User Menu***************************/
					else if(checkLogin=="user")
					{
						System.out.println("Hello User");
						System.out.println("************");
						do
						{
							System.out.println("User Menu:");
							System.out.println();
							System.out.println("1.  Search songs by Composer name.");
							System.out.println("2.  Search songs by Composer Music Society ID");
							System.out.println("3.  Edit an existing Composer details.");
							System.out.println("4.  Delete a Composer.");
							System.out.println("Enter your choice");
							choice3=sc.nextInt();
							switch(choice3)
							{
							case 1:
								System.out.print("Enter composer name:");
								composerName=sc.next()+sc.nextLine();

								try {
									songsList=songService.getSongsByName(composerName);
									if(songsList.size()==0)
									{
										try
										{
											throw new SongException("No songs related to the name "+
													composerName+" found :'( . Please try for other composers :) .");
										}
										catch(SongException e) {
											System.out.println(e.getMessage());
										}
									}

									else
									{
										for(SongMasterDTO songMasterDTOList:songsList)
											System.out.println(songMasterDTOList.displaySongsDetails());
									}
								} catch (SongException e) {
									// TODO Auto-generated catch block
									System.out.println(e.getMessage());
								}

								break;
							case 2:
								System.out.print("Enter music society ID:");
								String composerMusSocId=sc.next();
								try {
									songsList=songService.getSongsBySocId(composerMusSocId);
									if(songsList.size()==0)
									{
										try
										{
											throw new SongException("No songs related to the society Id "+
													composerMusSocId+" found :'( . Please try for other society Id :) .");
										}
										catch(SongException e) {
											System.out.println(e.getMessage());
										}
									}

									else
									{
										for(SongMasterDTO songMasterDTOList:songsList)
											System.out.println(songMasterDTOList.displaySongsDetails());
									}
								} catch (SongException e) {
									// TODO Auto-generated catch block
									System.out.println(e.getMessage());
								}

								break;
							}
							System.out.println("Want to continue (y/n)");
							choice5=sc.next().charAt(0);
						}while(choice5 =='y' || choice5=='Y');
					}
					else
					{
						System.err.println("Invalid userid password combination. Login denied."+
								(--count)+" attempts left");
						if(count==0)
							System.out.println("Sorry you have exhausted all your attempts. Please try after "
									+ "sometime.");

					}}
				while(count>0);

				break;

				/***************Case for sign up**********************/
			case 2:
				count=3;
				do
				{
					System.out.println("Enter  your Admin Credentials to add users");
					System.out.print("UserId (no space in userId): ");
					userId=sc.nextInt();
					System.out.println("Password: ");
					password=sc.next();
					checkLogin="invalid";
					try {
						checkLogin=songService.checkLogin(userId,password);
					} catch (SongException e) {
						// TODO Auto-generated catch block
						e.getMessage();
					}
					if(checkLogin=="admin")
					{
						System.out.println("UserId and Password successfully validated");
						System.out.println("Enter password for the user:");
						password=sc.next();
						userMasterDTO.setUserPassword(password);
						try {

							System.out.println("User succesfully added with user Id="
									+songService.addUser(userMasterDTO,userId));
						} catch (SongException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}
					else
					{
						System.err.println("Invalid userid password combination. Login denied."+
								(--count)+" attempts left");
						if(count==0)
							System.out.println("Sorry you have exhausted all your attempts. Please try after "
									+ "sometime.");

					}}
				while(count>0);
				break;

				/*Case for system exit*/
			case 3:
				System.out.println("Had a great time. Hope to see you soon.");
				System.exit(0);
				break;

			default:
				System.out.println("Please enter a valid choice.");


			}
		}while(true);
	}

}
