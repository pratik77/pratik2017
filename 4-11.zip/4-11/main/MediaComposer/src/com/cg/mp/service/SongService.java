package com.cg.mp.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.mp.dao.ArtistDAO;
import com.cg.mp.dao.ComposerDAO;
import com.cg.mp.dao.IArtistDAO;
import com.cg.mp.dao.IComposerDAO;
import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.dto.ComposerMasterDTO;
import com.cg.mp.dto.SongMasterDTO;
import com.cg.mp.dto.UserMasterDTO;
import com.cg.mp.exception.SongException;

public class SongService implements ISongService {
	IComposerDAO composerDAO=null	;
	IArtistDAO artistDAO=new ArtistDAO();
	public SongService() {
		// TODO Auto-generated constructor stub
		composerDAO=new ComposerDAO();
		artistDAO=new ArtistDAO();
	}

	@Override
	public String checkLogin(int userId, String password) throws SongException {
		// TODO Auto-generated method stub
		return composerDAO.checkLogin(userId,password);
	}

	@Override
	public int addComposer(ComposerMasterDTO composerMasterDTO, int userId) throws SongException {
		// TODO Auto-generated method stub
		return composerDAO.addComposer(composerMasterDTO,userId);
	}

	@Override
	public ComposerMasterDTO getComposerById(int composerId) throws SongException {
		// TODO Auto-generated method stub
		return composerDAO.getComposerById(composerId);
	}

	@Override
	public void editComposerDetails(ComposerMasterDTO composerMasterDTOEdit,int choice6,int userId) throws SongException {
		// TODO Auto-generated method stub
		composerDAO.editComposerDetails(composerMasterDTOEdit,choice6,userId);
	}

	@Override
	public void deleteComposerDetails(int composerId) throws SongException {
		// TODO Auto-generated method stub
		composerDAO.deleteComposerDetails(composerId);
	}

	@Override
	public List<ComposerMasterDTO> showAllComposerDetails()
			throws SongException {
		// TODO Auto-generated method stub
		return composerDAO.showAllComposerDetails();
	}

	@Override
	public int addUser(UserMasterDTO userMasterDTO, int userId)
			throws SongException {
		// TODO Auto-generated method stub
		return composerDAO.addUser(userMasterDTO, userId);
	}

	@Override
	public List<SongMasterDTO> getSongsByName(String composerName)
			throws SongException {
		// TODO Auto-generated method stub
		return composerDAO.getSongsByName(composerName);
	}

	@Override
	public List<SongMasterDTO> getSongsBySocId(String composerMusSocId)
			throws SongException {
		// TODO Auto-generated method stub
		return composerDAO.getSongsBySocId(composerMusSocId);
	}

	@Override
	public List<ArtistMasterDTO> searchArtist(int artistId)
			throws SongException {
		List<ArtistMasterDTO> artistList=artistDAO.searchArtist(artistId);
		return artistList;
	}
	@Override
	public int getArtistId() throws SongException {
		int artistId=artistDAO.getArtistId();
		return artistId;
	}
	@Override
	public int addNewArtist(ArtistMasterDTO artistMaster) throws SongException {
		int status=0;
		status=artistDAO.addNewArtist(artistMaster);
		return status;
	}
	@Override
	public void editArtistDetails(ArtistMasterDTO artistMasterDTOEdit,
			int choiceArtist) throws SongException {
		artistDAO.editArtistDetails(artistMasterDTOEdit,choiceArtist);
		
	}
	@Override
	public int deleteArtistDetails(int artistId) throws SongException {
		int status=0;
		status=artistDAO.deleteArtistDetails(artistId);
		return status;
		
	}
	@Override
	public List<ArtistMasterDTO> retrieveAllArtists() throws SongException {
		List<ArtistMasterDTO> artistList=artistDAO. retrieveAllArtists();
		return artistList;
	}
	@Override
	public List<ArtistMasterDTO> searchArtistByName(String artistName)
			throws SongException {
		List<ArtistMasterDTO> artistList=new ArrayList();
		artistList=artistDAO.searchArtistByName(artistName);
				return artistList;
		
	}
	@Override
	public List<ArtistMasterDTO> searchArtistByType(String artistType)
			throws SongException {
		
		List<ArtistMasterDTO> artistList=new ArrayList();
		artistList=artistDAO.searchArtistByType(artistType);
				return artistList;
	}
	@Override
	public List<SongMasterDTO> getSongsByArtistName(String searchartistName)
			throws SongException {
		
		return artistDAO.getSongsByName(searchartistName);
	}
	
}
